import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// === TABLE DEFINITIONS ===

export const scannedAddresses = pgTable("scanned_addresses", {
  id: serial("id").primaryKey(),
  address: text("address").notNull().unique(),
  balance: text("balance"), // Store as text to handle large precision or "BTC" string
  txCount: integer("tx_count"),
  riskScore: integer("risk_score").default(0),
  priority: text("priority").default("LOW"), // HIGH, MEDIUM, LOW
  status: text("status").default("pending"), // pending, scanning, analyzed, secure, vulnerable
  lastScanned: timestamp("last_scanned"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const vulnerabilities = pgTable("vulnerabilities", {
  id: serial("id").primaryKey(),
  addressId: integer("address_id").references(() => scannedAddresses.id),
  type: text("type").notNull(), // nonce_reuse, polynomial, weak_nonce
  severity: text("severity").notNull(), // CRITICAL, HIGH, MEDIUM, LOW
  data: jsonb("data"), // Stores specific vulnerability details
  recoveredKey: text("recovered_key"), // If key recovery was successful
  detectedAt: timestamp("detected_at").defaultNow(),
});

export const systemLogs = pgTable("system_logs", {
  id: serial("id").primaryKey(),
  level: text("level").notNull(), // INFO, WARNING, ERROR, SUCCESS
  component: text("component").notNull(), // Collector, Analyzer, Alerter
  message: text("message").notNull(),
  details: jsonb("details"),
  timestamp: timestamp("timestamp").defaultNow(),
});

// === SCHEMAS ===

export const insertAddressSchema = createInsertSchema(scannedAddresses).omit({ 
  id: true, 
  lastScanned: true, 
  createdAt: true 
});

export const insertVulnerabilitySchema = createInsertSchema(vulnerabilities).omit({ 
  id: true, 
  detectedAt: true 
});

export const insertLogSchema = createInsertSchema(systemLogs).omit({ 
  id: true, 
  timestamp: true 
});

// === TYPES ===

export type ScannedAddress = typeof scannedAddresses.$inferSelect;
export type InsertAddress = z.infer<typeof insertAddressSchema>;

export type Vulnerability = typeof vulnerabilities.$inferSelect;
export type InsertVulnerability = z.infer<typeof insertVulnerabilitySchema>;

export type SystemLog = typeof systemLogs.$inferSelect;
export type InsertLog = z.infer<typeof insertLogSchema>;

// === API CONTRACT TYPES ===

export type AddressResponse = ScannedAddress & {
  vulnerabilities?: Vulnerability[];
};

export type DashboardStats = {
  totalScanned: number;
  vulnerableCount: number;
  highPriorityCount: number;
  activeThreads: number;
};
