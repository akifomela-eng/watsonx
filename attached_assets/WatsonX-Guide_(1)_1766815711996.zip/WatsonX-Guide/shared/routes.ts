import { z } from 'zod';
import { insertAddressSchema, insertVulnerabilitySchema, scannedAddresses, vulnerabilities, systemLogs } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  addresses: {
    list: {
      method: 'GET' as const,
      path: '/api/addresses',
      input: z.object({
        priority: z.enum(['HIGH', 'MEDIUM', 'LOW']).optional(),
        status: z.enum(['pending', 'scanning', 'analyzed', 'secure', 'vulnerable']).optional(),
        limit: z.coerce.number().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof scannedAddresses.$inferSelect>()),
      },
    },
    get: {
      method: 'GET' as const,
      path: '/api/addresses/:id',
      responses: {
        200: z.custom<typeof scannedAddresses.$inferSelect & { vulnerabilities: typeof vulnerabilities.$inferSelect[] }>(),
        404: errorSchemas.notFound,
      },
    },
    create: {
      method: 'POST' as const,
      path: '/api/addresses',
      input: insertAddressSchema,
      responses: {
        201: z.custom<typeof scannedAddresses.$inferSelect>(),
        400: errorSchemas.validation,
      },
    },
  },
  vulnerabilities: {
    list: {
      method: 'GET' as const,
      path: '/api/vulnerabilities',
      responses: {
        200: z.array(z.custom<typeof vulnerabilities.$inferSelect & { address: string }>()),
      },
    },
  },
  logs: {
    list: {
      method: 'GET' as const,
      path: '/api/logs',
      input: z.object({
        limit: z.coerce.number().optional().default(50),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof systemLogs.$inferSelect>()),
      },
    },
  },
  stats: {
    get: {
      method: 'GET' as const,
      path: '/api/stats',
      responses: {
        200: z.object({
          totalScanned: z.number(),
          vulnerableCount: z.number(),
          highPriorityCount: z.number(),
          activeThreads: z.number(),
        }),
      },
    },
  },
  scanner: {
    action: {
      method: 'POST' as const,
      path: '/api/scanner/action',
      input: z.object({
        action: z.enum(['start', 'stop', 'pause']),
      }),
      responses: {
        200: z.object({ status: z.string(), message: z.string() }),
      },
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
