## Packages
recharts | Data visualization for dashboard metrics
framer-motion | Animation library for smooth UI transitions
date-fns | Date formatting for logs and timestamps
clsx | Utility for constructing className strings conditionally
tailwind-merge | Utility for merging Tailwind CSS classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  mono: ["var(--font-mono)"],
  sans: ["var(--font-sans)"],
}

API Integration:
- All data fetching uses TanStack Query v5
- Routes are defined in shared/routes.ts
- Authentication is assumed to be handled via cookie sessions (credentials: "include")
