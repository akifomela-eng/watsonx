import { Sidebar } from "@/components/Sidebar";
import { useVulnerabilities } from "@/hooks/use-vulnerabilities";
import { Bug, ShieldCheck, AlertTriangle, Key } from "lucide-react";
import { clsx } from "clsx";
import { format } from "date-fns";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";

export default function Vulnerabilities() {
  const { data: vulns, isLoading } = useVulnerabilities();

  return (
    <div className="flex min-h-screen bg-background text-foreground font-sans">
      <Sidebar />
      
      <main className="flex-1 ml-64 p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-display font-bold tracking-wider text-foreground">Identified Threats</h2>
            <p className="text-muted-foreground font-mono text-sm mt-1">
              Critical Security Flaws Found: <span className="text-red-500 font-bold">{vulns?.length || 0}</span>
            </p>
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center h-64 border border-border rounded-xl bg-card/50">
            <div className="flex flex-col items-center gap-3 animate-pulse">
              <Bug className="w-8 h-8 text-primary" />
              <span className="font-mono text-primary text-sm">SCANNING DATABASE...</span>
            </div>
          </div>
        ) : vulns?.length === 0 ? (
          <div className="flex items-center justify-center h-64 border border-green-500/20 rounded-xl bg-green-500/5">
            <div className="flex flex-col items-center gap-3">
              <ShieldCheck className="w-12 h-12 text-green-500" />
              <span className="font-display text-green-500 text-lg font-bold tracking-wide">NO VULNERABILITIES DETECTED</span>
              <p className="text-muted-foreground text-sm font-mono">System appears secure.</p>
            </div>
          </div>
        ) : (
          <div className="grid gap-6">
            {vulns?.map((vuln) => (
              <Card key={vuln.id} className="bg-card/80 border-l-4 border-l-red-500 border-y border-r border-border overflow-hidden relative group hover:bg-card/90 transition-all">
                {/* Background decorative elements */}
                <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
                  <AlertTriangle className="w-32 h-32" />
                </div>
                
                <div className="flex flex-col md:flex-row gap-6 p-6 relative z-10">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 rounded-lg bg-red-500/10 flex items-center justify-center border border-red-500/20">
                      <Bug className="w-6 h-6 text-red-500" />
                    </div>
                  </div>
                  
                  <div className="flex-1 space-y-4">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="text-lg font-bold font-display tracking-wide flex items-center gap-3">
                          {vuln.type.toUpperCase().replace(/_/g, " ")}
                          <span className="text-xs px-2 py-1 rounded bg-red-500 text-white font-mono">{vuln.severity}</span>
                        </h3>
                        <p className="text-sm font-mono text-muted-foreground mt-1">
                          Detected in: <span className="text-primary">{vuln.address}</span>
                        </p>
                      </div>
                      <span className="text-xs font-mono text-muted-foreground border border-border px-2 py-1 rounded">
                        {vuln.detectedAt ? format(new Date(vuln.detectedAt), "yyyy-MM-dd HH:mm:ss") : "Unknown"}
                      </span>
                    </div>

                    <div className="bg-black/40 rounded-lg p-4 font-mono text-xs border border-primary/10 overflow-x-auto">
                      <div className="grid grid-cols-[100px_1fr] gap-2">
                        <span className="text-muted-foreground">DETAILS:</span>
                        <span className="text-foreground">{JSON.stringify(vuln.data)}</span>
                        
                        {vuln.recoveredKey && (
                          <>
                            <span className="text-red-500 font-bold mt-2">PRIVATE KEY:</span>
                            <span className="text-red-400 mt-2 font-bold blur-sm hover:blur-none transition-all cursor-crosshair flex items-center gap-2">
                              <Key className="w-3 h-3" />
                              {vuln.recoveredKey}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
