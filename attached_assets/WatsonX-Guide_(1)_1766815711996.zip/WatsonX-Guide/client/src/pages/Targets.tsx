import { Sidebar } from "@/components/Sidebar";
import { AddTargetDialog } from "@/components/AddTargetDialog";
import { useAddresses } from "@/hooks/use-addresses";
import { Input } from "@/components/ui/input";
import { Search, Filter, RefreshCw } from "lucide-react";
import { clsx } from "clsx";
import { format } from "date-fns";
import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Targets() {
  const [priorityFilter, setPriorityFilter] = useState<string | undefined>();
  const [statusFilter, setStatusFilter] = useState<string | undefined>();
  
  const { data: targets, isLoading, refetch } = useAddresses({
    priority: priorityFilter,
    status: statusFilter,
    limit: 100
  });

  return (
    <div className="flex min-h-screen bg-background text-foreground font-sans">
      <Sidebar />
      
      <main className="flex-1 ml-64 p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-display font-bold tracking-wider text-foreground">Target Registry</h2>
            <p className="text-muted-foreground font-mono text-sm mt-1">
              {targets?.length || 0} Addresses Monitored
            </p>
          </div>
          <AddTargetDialog />
        </div>

        {/* Filters Bar */}
        <div className="flex items-center gap-4 mb-6 p-4 bg-card/50 border border-border rounded-xl backdrop-blur-sm">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search address..." 
              className="pl-9 bg-black/20 border-primary/10 focus:border-primary/50 font-mono text-sm" 
            />
          </div>
          
          <div className="flex items-center gap-2 border-l border-border/50 pl-4">
            <Filter className="w-4 h-4 text-muted-foreground" />
            <Select onValueChange={(val) => setPriorityFilter(val === 'ALL' ? undefined : val)}>
              <SelectTrigger className="w-[140px] bg-black/20 border-primary/10 font-mono text-xs">
                <SelectValue placeholder="Priority: All" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Priorities</SelectItem>
                <SelectItem value="HIGH">High</SelectItem>
                <SelectItem value="MEDIUM">Medium</SelectItem>
                <SelectItem value="LOW">Low</SelectItem>
              </SelectContent>
            </Select>

            <Select onValueChange={(val) => setStatusFilter(val === 'ALL' ? undefined : val)}>
              <SelectTrigger className="w-[140px] bg-black/20 border-primary/10 font-mono text-xs">
                <SelectValue placeholder="Status: All" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All Statuses</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="scanning">Scanning</SelectItem>
                <SelectItem value="vulnerable">Vulnerable</SelectItem>
                <SelectItem value="secure">Secure</SelectItem>
              </SelectContent>
            </Select>
            
            <button 
              onClick={() => refetch()}
              className="p-2 hover:bg-white/5 rounded-lg transition-colors text-muted-foreground hover:text-primary"
            >
              <RefreshCw className={clsx("w-4 h-4", isLoading && "animate-spin")} />
            </button>
          </div>
        </div>

        {/* Data Table */}
        <div className="rounded-xl border border-border bg-card/50 backdrop-blur-sm overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-muted-foreground uppercase bg-black/40 font-mono border-b border-border/50">
                <tr>
                  <th className="px-6 py-4">ID</th>
                  <th className="px-6 py-4">Wallet Address</th>
                  <th className="px-6 py-4">Balance</th>
                  <th className="px-6 py-4">Tx Count</th>
                  <th className="px-6 py-4">Risk Score</th>
                  <th className="px-6 py-4">Priority</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4 text-right">Last Scan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/30">
                {isLoading ? (
                  <tr>
                    <td colSpan={8} className="px-6 py-12 text-center text-muted-foreground font-mono animate-pulse">
                      LOADING DATA...
                    </td>
                  </tr>
                ) : targets?.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-6 py-12 text-center text-muted-foreground font-mono">
                      NO TARGETS FOUND
                    </td>
                  </tr>
                ) : (
                  targets?.map((target) => (
                    <tr key={target.id} className="hover:bg-white/5 transition-colors group">
                      <td className="px-6 py-4 font-mono text-muted-foreground/50">#{target.id}</td>
                      <td className="px-6 py-4 font-mono text-xs text-primary/80 group-hover:text-primary transition-colors cursor-pointer">
                        {target.address}
                      </td>
                      <td className="px-6 py-4 font-mono text-xs">{target.balance || '0'} BTC</td>
                      <td className="px-6 py-4 font-mono text-xs">{target.txCount || 0}</td>
                      <td className="px-6 py-4">
                        <div className="w-full bg-white/5 rounded-full h-1.5 max-w-[80px]">
                          <div 
                            className={clsx("h-1.5 rounded-full", target.riskScore && target.riskScore > 50 ? "bg-red-500" : "bg-green-500")}
                            style={{ width: `${target.riskScore || 0}%` }}
                          />
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className={clsx(
                          "text-xs font-bold",
                          target.priority === 'HIGH' ? "text-red-500" :
                          target.priority === 'MEDIUM' ? "text-amber-500" : "text-muted-foreground"
                        )}>
                          {target.priority}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <span className={clsx(
                          "px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide border",
                          target.status === 'vulnerable' ? "bg-red-500/10 text-red-500 border-red-500/20" :
                          target.status === 'secure' ? "bg-green-500/10 text-green-500 border-green-500/20" :
                          target.status === 'scanning' ? "bg-amber-500/10 text-amber-500 border-amber-500/20 animate-pulse" :
                          "bg-blue-500/10 text-blue-500 border-blue-500/20"
                        )}>
                          {target.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-right text-xs font-mono text-muted-foreground">
                        {target.lastScanned ? format(new Date(target.lastScanned), 'dd MMM HH:mm') : '-'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}
