import { Sidebar } from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Save, RefreshCw } from "lucide-react";

export default function Settings() {
  return (
    <div className="flex min-h-screen bg-background text-foreground font-sans">
      <Sidebar />
      
      <main className="flex-1 ml-64 p-8">
        <div className="mb-8">
          <h2 className="text-2xl font-display font-bold tracking-wider text-foreground">System Configuration</h2>
          <p className="text-muted-foreground font-mono text-sm mt-1">
            Manage scanner parameters and API keys
          </p>
        </div>

        <div className="grid gap-8 max-w-4xl">
          <Card className="bg-card/50 border border-border backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="font-display text-lg">Scanner Engine</CardTitle>
              <CardDescription className="font-mono text-xs">Adjust scanning speed and thread allocation</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <Label className="text-sm font-bold">Auto-Scan New Blocks</Label>
                  <p className="text-xs text-muted-foreground">Automatically ingest transactions from new blocks</p>
                </div>
                <Switch defaultChecked />
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-bold">Max Concurrent Threads</Label>
                <div className="flex items-center gap-4">
                  <Input type="number" defaultValue={8} className="w-24 bg-black/20 font-mono" />
                  <span className="text-xs text-muted-foreground">Recommended: 8-16 for current hardware</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border border-border backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="font-display text-lg">API Connections</CardTitle>
              <CardDescription className="font-mono text-xs">External service credentials</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label className="text-sm font-bold">Ethereum Node RPC</Label>
                <div className="flex gap-2">
                  <Input defaultValue="wss://mainnet.infura.io/ws/v3/..." className="font-mono text-xs bg-black/20 border-primary/20" type="password" />
                  <Button variant="outline" size="icon" className="shrink-0">
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              <div className="space-y-2">
                <Label className="text-sm font-bold">Etherscan API Key</Label>
                <Input defaultValue="••••••••••••••••" className="font-mono text-xs bg-black/20 border-primary/20" type="password" />
              </div>
            </CardContent>
          </Card>

          <div className="flex justify-end gap-4">
            <Button variant="outline" className="font-mono">RESET TO DEFAULTS</Button>
            <Button className="bg-primary text-primary-foreground gap-2 font-bold font-mono">
              <Save className="w-4 h-4" /> SAVE CONFIGURATION
            </Button>
          </div>
        </div>
      </main>
    </div>
  );
}
