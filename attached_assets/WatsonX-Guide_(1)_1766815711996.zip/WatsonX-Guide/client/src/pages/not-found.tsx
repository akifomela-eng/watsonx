import { Link } from "wouter";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function NotFound() {
  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-background p-4">
      <div className="max-w-md w-full text-center space-y-6">
        <div className="flex justify-center">
          <div className="w-24 h-24 rounded-full bg-red-500/10 flex items-center justify-center border border-red-500/30 animate-pulse">
            <AlertTriangle className="w-12 h-12 text-red-500" />
          </div>
        </div>
        
        <div className="space-y-2">
          <h1 className="text-4xl font-display font-bold text-foreground tracking-widest">404</h1>
          <h2 className="text-xl font-mono text-primary font-bold">SYSTEM ERROR: RESOURCE NOT FOUND</h2>
          <p className="text-muted-foreground text-sm font-mono">
            The requested sector coordinates do not exist in the current grid.
          </p>
        </div>

        <Link href="/">
          <Button className="w-full bg-primary text-primary-foreground font-mono font-bold tracking-wide">
            RETURN TO MISSION CONTROL
          </Button>
        </Link>
      </div>
      
      {/* Background grid effect */}
      <div className="absolute inset-0 z-[-1] opacity-10 pointer-events-none bg-[size:50px_50px] bg-[linear-gradient(to_right,#8080800a_1px,transparent_1px),linear-gradient(to_bottom,#8080800a_1px,transparent_1px)]" />
    </div>
  );
}
