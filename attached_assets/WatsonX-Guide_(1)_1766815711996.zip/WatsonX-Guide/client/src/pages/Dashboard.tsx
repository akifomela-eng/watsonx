import { Sidebar } from "@/components/Sidebar";
import { StatCard } from "@/components/StatCard";
import { TerminalLog } from "@/components/TerminalLog";
import { AddTargetDialog } from "@/components/AddTargetDialog";
import { useStats, useScannerAction } from "@/hooks/use-dashboard";
import { useAddresses } from "@/hooks/use-addresses";
import { ShieldAlert, Activity, Crosshair, Cpu, Play, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { clsx } from "clsx";
import { format } from "date-fns";
import { Link } from "wouter";

export default function Dashboard() {
  const { data: stats } = useStats();
  const { data: recentTargets } = useAddresses({ limit: 5 });
  const scannerMutation = useScannerAction();

  const handleScannerToggle = () => {
    // Simple toggle logic for demo purposes
    const action = stats?.activeThreads && stats.activeThreads > 0 ? 'stop' : 'start';
    scannerMutation.mutate(action);
  };

  return (
    <div className="flex min-h-screen bg-background text-foreground font-sans">
      <Sidebar />
      
      <main className="flex-1 ml-64 p-8">
        {/* Header Section */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-display font-bold tracking-wider text-foreground">Mission Control</h2>
            <p className="text-muted-foreground font-mono text-sm mt-1">
              System Status: <span className="text-primary glow-text">OPERATIONAL</span>
            </p>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-4 py-2 bg-card/50 border border-border rounded-lg">
              <div className={clsx("w-2 h-2 rounded-full animate-pulse", stats?.activeThreads ? "bg-primary" : "bg-red-500")} />
              <span className="font-mono text-xs uppercase tracking-wider">
                Scanner: {stats?.activeThreads ? "ACTIVE" : "IDLE"}
              </span>
            </div>
            
            <Button 
              onClick={handleScannerToggle}
              disabled={scannerMutation.isPending}
              variant="outline"
              className={clsx(
                "border-primary/20 gap-2 font-mono uppercase tracking-wide",
                stats?.activeThreads ? "hover:bg-red-500/10 hover:text-red-500 hover:border-red-500/50" : "hover:bg-primary/10 hover:text-primary hover:border-primary/50"
              )}
            >
              {scannerMutation.isPending ? (
                <Activity className="w-4 h-4 animate-spin" />
              ) : stats?.activeThreads ? (
                <><Square className="w-4 h-4 fill-current" /> STOP SCANNER</>
              ) : (
                <><Play className="w-4 h-4 fill-current" /> START SCANNER</>
              )}
            </Button>
            
            <AddTargetDialog />
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard 
            title="Active Targets" 
            value={stats?.totalScanned || 0} 
            icon={Crosshair} 
            trend="+12" 
            trendDirection="up"
            color="info"
          />
          <StatCard 
            title="Vulnerabilities" 
            value={stats?.vulnerableCount || 0} 
            icon={ShieldAlert} 
            trend="+3" 
            trendDirection="down"
            color="destructive"
          />
          <StatCard 
            title="Active Threads" 
            value={stats?.activeThreads || 0} 
            icon={Cpu} 
            color="primary"
          />
          <StatCard 
            title="High Priority" 
            value={stats?.highPriorityCount || 0} 
            icon={Activity} 
            color="warning"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Chart/Map Area (Placeholder for visual complexity) */}
          <div className="lg:col-span-2 space-y-6">
            <div className="rounded-xl border border-border bg-card/50 backdrop-blur-sm p-6 overflow-hidden relative">
              <div className="flex justify-between items-center mb-6">
                <h3 className="font-display font-bold text-lg tracking-wide flex items-center gap-2">
                  <Activity className="w-5 h-5 text-primary" />
                  Recent Scans
                </h3>
                <Link href="/targets" className="text-xs text-primary hover:underline font-mono cursor-pointer">VIEW ALL &rarr;</Link>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-sm text-left">
                  <thead className="text-xs text-muted-foreground uppercase bg-white/5 font-mono">
                    <tr>
                      <th className="px-4 py-3 rounded-l-md">Address</th>
                      <th className="px-4 py-3">Status</th>
                      <th className="px-4 py-3">Priority</th>
                      <th className="px-4 py-3 text-right rounded-r-md">Last Scanned</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border/30">
                    {recentTargets?.map((target) => (
                      <tr key={target.id} className="hover:bg-white/5 transition-colors group">
                        <td className="px-4 py-3 font-mono text-xs text-muted-foreground group-hover:text-foreground">
                          {target.address.substring(0, 8)}...{target.address.substring(target.address.length - 8)}
                        </td>
                        <td className="px-4 py-3">
                          <span className={clsx(
                            "px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wide border",
                            target.status === 'vulnerable' ? "bg-red-500/10 text-red-500 border-red-500/20" :
                            target.status === 'secure' ? "bg-green-500/10 text-green-500 border-green-500/20" :
                            "bg-blue-500/10 text-blue-500 border-blue-500/20"
                          )}>
                            {target.status}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <span className={clsx(
                            "text-xs font-bold",
                            target.priority === 'HIGH' ? "text-red-500" :
                            target.priority === 'MEDIUM' ? "text-amber-500" : "text-muted-foreground"
                          )}>
                            {target.priority}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right text-xs font-mono text-muted-foreground">
                          {target.lastScanned ? format(new Date(target.lastScanned), 'HH:mm:ss') : '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Grid for smaller widgets */}
            <div className="grid grid-cols-2 gap-6">
               <div className="rounded-xl border border-border bg-card/50 p-6 flex flex-col items-center justify-center text-center relative overflow-hidden group">
                  <div className="absolute inset-0 bg-primary/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <Cpu className="w-10 h-10 text-primary mb-3" />
                  <h4 className="font-mono text-sm font-bold">System Load</h4>
                  <p className="text-2xl font-display font-bold mt-1 text-foreground">32%</p>
               </div>
               <div className="rounded-xl border border-border bg-card/50 p-6 flex flex-col items-center justify-center text-center relative overflow-hidden group">
                  <div className="absolute inset-0 bg-destructive/5 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <ShieldAlert className="w-10 h-10 text-destructive mb-3" />
                  <h4 className="font-mono text-sm font-bold">Risk Index</h4>
                  <p className="text-2xl font-display font-bold mt-1 text-foreground">LOW</p>
               </div>
            </div>
          </div>

          {/* Right Column: Terminal */}
          <div className="lg:col-span-1">
            <TerminalLog />
          </div>
        </div>
      </main>
    </div>
  );
}
