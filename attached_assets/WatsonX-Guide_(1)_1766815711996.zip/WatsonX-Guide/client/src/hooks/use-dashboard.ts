import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type DashboardStats } from "@shared/routes";
import { z } from "zod";

export function useStats() {
  return useQuery({
    queryKey: [api.stats.get.path],
    queryFn: async () => {
      const res = await fetch(api.stats.get.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch dashboard stats");
      return api.stats.get.responses[200].parse(await res.json());
    },
    refetchInterval: 5000, // Real-time stats
  });
}

export function useScannerAction() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (action: 'start' | 'stop' | 'pause') => {
      const res = await fetch(api.scanner.action.path, {
        method: api.scanner.action.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
        credentials: "include",
      });
      if (!res.ok) throw new Error(`Failed to ${action} scanner`);
      return api.scanner.action.responses[200].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.stats.get.path] });
    },
  });
}

export function useLogs() {
  return useQuery({
    queryKey: [api.logs.list.path],
    queryFn: async () => {
      const res = await fetch(`${api.logs.list.path}?limit=50`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch logs");
      return api.logs.list.responses[200].parse(await res.json());
    },
    refetchInterval: 2000, // Frequent polling for live terminal feel
  });
}
