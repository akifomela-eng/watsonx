import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, buildUrl, type InsertAddress } from "@shared/routes";
import { z } from "zod";

export function useAddresses(filters?: { priority?: string; status?: string; limit?: number }) {
  const queryKey = [api.addresses.list.path, filters];
  return useQuery({
    queryKey,
    queryFn: async () => {
      const params = new URLSearchParams();
      if (filters?.priority) params.append("priority", filters.priority);
      if (filters?.status) params.append("status", filters.status);
      if (filters?.limit) params.append("limit", filters.limit.toString());
      
      const url = `${api.addresses.list.path}?${params.toString()}`;
      const res = await fetch(url, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch addresses");
      return api.addresses.list.responses[200].parse(await res.json());
    },
  });
}

export function useAddress(id: number) {
  return useQuery({
    queryKey: [api.addresses.get.path, id],
    queryFn: async () => {
      const url = buildUrl(api.addresses.get.path, { id });
      const res = await fetch(url, { credentials: "include" });
      if (res.status === 404) return null;
      if (!res.ok) throw new Error("Failed to fetch address details");
      return api.addresses.get.responses[200].parse(await res.json());
    },
  });
}

export function useCreateAddress() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: InsertAddress) => {
      const validated = api.addresses.create.input.parse(data);
      const res = await fetch(api.addresses.create.path, {
        method: api.addresses.create.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      
      if (!res.ok) {
        if (res.status === 400) {
          const error = api.addresses.create.responses[400].parse(await res.json());
          throw new Error(error.message);
        }
        throw new Error("Failed to add target address");
      }
      return api.addresses.create.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.addresses.list.path] });
    },
  });
}
