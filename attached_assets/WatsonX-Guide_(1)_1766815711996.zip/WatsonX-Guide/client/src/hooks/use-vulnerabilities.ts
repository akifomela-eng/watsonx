import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useVulnerabilities() {
  return useQuery({
    queryKey: [api.vulnerabilities.list.path],
    queryFn: async () => {
      const res = await fetch(api.vulnerabilities.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch vulnerabilities");
      return api.vulnerabilities.list.responses[200].parse(await res.json());
    },
  });
}
