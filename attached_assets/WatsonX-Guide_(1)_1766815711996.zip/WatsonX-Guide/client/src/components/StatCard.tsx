import { LucideIcon } from "lucide-react";
import { clsx } from "clsx";

interface StatCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: string;
  trendDirection?: 'up' | 'down' | 'neutral';
  color?: 'primary' | 'destructive' | 'warning' | 'info';
  className?: string;
}

export function StatCard({ 
  title, 
  value, 
  icon: Icon, 
  trend, 
  trendDirection, 
  color = 'primary',
  className 
}: StatCardProps) {
  const colorStyles = {
    primary: "text-primary bg-primary/10 border-primary/20",
    destructive: "text-destructive bg-destructive/10 border-destructive/20",
    warning: "text-amber-500 bg-amber-500/10 border-amber-500/20",
    info: "text-blue-500 bg-blue-500/10 border-blue-500/20",
  };

  const iconStyles = {
    primary: "text-primary",
    destructive: "text-destructive",
    warning: "text-amber-500",
    info: "text-blue-500",
  };

  return (
    <div className={clsx(
      "relative overflow-hidden p-6 rounded-xl border bg-card/50 backdrop-blur-sm transition-all duration-300 hover:shadow-lg group",
      colorStyles[color].replace('text-', 'border-'), // Use border color
      className
    )}>
      <div className="absolute top-0 right-0 p-3 opacity-10 transform translate-x-1/4 -translate-y-1/4 group-hover:scale-110 transition-transform">
        <Icon className="w-24 h-24" />
      </div>

      <div className="relative z-10 flex flex-col justify-between h-full">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-mono text-muted-foreground uppercase tracking-wider">{title}</h3>
          <div className={clsx("p-2 rounded-lg", colorStyles[color])}>
            <Icon className="w-5 h-5" />
          </div>
        </div>
        
        <div>
          <div className={clsx("text-3xl font-display font-bold mb-1", iconStyles[color])}>
            {value}
          </div>
          {trend && (
            <div className="flex items-center gap-2 text-xs font-mono">
              <span className={clsx(
                trendDirection === 'up' ? "text-green-500" : 
                trendDirection === 'down' ? "text-red-500" : "text-muted-foreground"
              )}>
                {trendDirection === 'up' ? '↑' : trendDirection === 'down' ? '↓' : '→'} {trend}
              </span>
              <span className="text-muted-foreground/50">vs last hour</span>
            </div>
          )}
        </div>
      </div>
      
      {/* Decorative scanline effect */}
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-current to-transparent opacity-20" />
    </div>
  );
}
