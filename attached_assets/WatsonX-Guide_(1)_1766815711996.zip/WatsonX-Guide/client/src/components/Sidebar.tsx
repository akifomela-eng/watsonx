import { Link, useLocation } from "wouter";
import { Shield, LayoutDashboard, Target, Bug, Settings, Activity } from "lucide-react";
import { clsx } from "clsx";

export function Sidebar() {
  const [location] = useLocation();

  const navItems = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/targets", label: "Targets", icon: Target },
    { href: "/vulnerabilities", label: "Vulnerabilities", icon: Bug },
    { href: "/settings", label: "System Config", icon: Settings },
  ];

  return (
    <aside className="fixed left-0 top-0 h-full w-64 bg-card/95 border-r border-border backdrop-blur-xl z-50 flex flex-col">
      <div className="p-6 border-b border-border/50">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded bg-primary/20 flex items-center justify-center border border-primary/30 shadow-[0_0_15px_-3px_rgba(16,185,129,0.3)]">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h1 className="font-display font-bold text-lg tracking-wider text-foreground">CYBER<span className="text-primary">SEC</span></h1>
            <p className="text-xs text-muted-foreground font-mono">v2.4.0_BETA</p>
          </div>
        </div>
      </div>

      <nav className="flex-1 px-4 py-6 space-y-2 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location === item.href;
          const Icon = item.icon;
          
          return (
            <Link key={item.href} href={item.href}>
              <div 
                className={clsx(
                  "flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 cursor-pointer group border border-transparent",
                  isActive 
                    ? "bg-primary/10 text-primary border-primary/20 shadow-[inset_0_0_10px_rgba(16,185,129,0.1)]" 
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                )}
              >
                <Icon className={clsx("w-5 h-5", isActive ? "text-primary animate-pulse" : "text-muted-foreground group-hover:text-foreground")} />
                <span className="font-mono tracking-wide">{item.label}</span>
                {isActive && (
                  <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
                )}
              </div>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-border/50 bg-black/20">
        <div className="flex items-center gap-3 px-4 py-3 rounded-lg border border-border/50 bg-card/50">
          <Activity className="w-4 h-4 text-green-500 animate-pulse" />
          <div>
            <p className="text-xs font-mono text-muted-foreground">System Status</p>
            <p className="text-sm font-bold text-green-500 font-display tracking-wide">ONLINE</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
