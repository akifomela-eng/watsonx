import { useEffect, useRef } from "react";
import { useLogs } from "@/hooks/use-dashboard";
import { format } from "date-fns";
import { clsx } from "clsx";
import { Terminal, Activity, AlertTriangle, CheckCircle, Info } from "lucide-react";

export function TerminalLog() {
  const { data: logs, isLoading } = useLogs();
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const getLogIcon = (level: string) => {
    switch (level) {
      case 'ERROR': return <AlertTriangle className="w-3 h-3 text-red-500" />;
      case 'WARNING': return <Activity className="w-3 h-3 text-amber-500" />;
      case 'SUCCESS': return <CheckCircle className="w-3 h-3 text-green-500" />;
      default: return <Info className="w-3 h-3 text-blue-500" />;
    }
  };

  const getLogColor = (level: string) => {
    switch (level) {
      case 'ERROR': return "text-red-400";
      case 'WARNING': return "text-amber-400";
      case 'SUCCESS': return "text-green-400";
      default: return "text-blue-300";
    }
  };

  if (isLoading) {
    return (
      <div className="h-[400px] rounded-lg border border-primary/20 bg-black/80 flex items-center justify-center">
        <div className="flex flex-col items-center gap-2">
          <Terminal className="w-8 h-8 text-primary animate-pulse" />
          <span className="text-xs text-primary font-mono animate-pulse">INITIALIZING SYSTEM LOGS...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-[400px] rounded-lg border border-primary/20 bg-black/90 shadow-[0_0_20px_rgba(0,0,0,0.5)] overflow-hidden font-mono text-sm relative">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-2 border-b border-primary/20 bg-primary/5">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-primary" />
          <span className="text-xs font-bold text-primary tracking-widest uppercase">Live System Logs</span>
        </div>
        <div className="flex gap-1.5">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500/50" />
          <div className="w-2.5 h-2.5 rounded-full bg-amber-500/50" />
          <div className="w-2.5 h-2.5 rounded-full bg-green-500/50" />
        </div>
      </div>

      {/* Content */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-1.5 scroll-smooth"
      >
        {!logs?.length && (
          <div className="text-muted-foreground/50 italic text-xs p-2 text-center">-- No logs available --</div>
        )}
        
        {logs?.map((log) => (
          <div key={log.id} className="flex items-start gap-3 hover:bg-white/5 p-1 rounded transition-colors group">
            <span className="text-muted-foreground/40 text-[10px] whitespace-nowrap pt-1 font-mono">
              {log.timestamp ? format(new Date(log.timestamp), "HH:mm:ss.SSS") : "---"}
            </span>
            <div className="pt-1">{getLogIcon(log.level)}</div>
            <div className="flex-1 break-all">
              <span className={clsx("font-bold mr-2 text-xs", getLogColor(log.level))}>
                [{log.component}]
              </span>
              <span className="text-muted-foreground group-hover:text-foreground transition-colors">
                {log.message}
              </span>
            </div>
          </div>
        ))}
        {/* Cursor effect */}
        <div className="flex items-center gap-2 mt-2 pl-1 animate-pulse">
          <span className="text-primary font-bold">{'>'}</span>
          <div className="w-2 h-4 bg-primary" />
        </div>
      </div>

      {/* Scanline overlay */}
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] z-10 bg-[length:100%_2px,3px_100%] opacity-20" />
    </div>
  );
}
