import { useState } from "react";
import { useCreateAddress } from "@/hooks/use-addresses";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertAddressSchema, type InsertAddress } from "@shared/schema";
import { 
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
  DialogDescription, DialogFooter
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Loader2, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

// Extend schema for form validation
const formSchema = insertAddressSchema.pick({ address: true, priority: true });
type FormData = z.infer<typeof formSchema>;

export function AddTargetDialog() {
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const createAddress = useCreateAddress();
  
  const { register, handleSubmit, reset, setValue, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      priority: "LOW"
    }
  });

  const onSubmit = (data: FormData) => {
    createAddress.mutate(data, {
      onSuccess: () => {
        toast({
          title: "Target Added",
          description: `Successfully initiated scan for ${data.address}`,
          variant: "default",
          className: "border-primary/50 bg-primary/10 text-primary-foreground",
        });
        setOpen(false);
        reset();
      },
      onError: (err) => {
        toast({
          title: "Error",
          description: err.message,
          variant: "destructive",
        });
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2 bg-primary hover:bg-primary/90 text-primary-foreground font-bold shadow-[0_0_15px_-3px_rgba(16,185,129,0.5)] border border-primary/20">
          <Plus className="w-4 h-4" />
          ADD TARGET
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px] bg-card/95 backdrop-blur border-primary/20 shadow-2xl">
        <DialogHeader>
          <DialogTitle className="font-display tracking-wide text-primary">New Scan Target</DialogTitle>
          <DialogDescription className="text-muted-foreground/80 font-mono text-xs">
            Add a new blockchain address to the vulnerability scanner queue.
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 pt-4">
          <div className="space-y-2">
            <Label htmlFor="address" className="font-mono text-xs uppercase text-primary/80">Wallet Address</Label>
            <Input 
              id="address" 
              placeholder="0x..." 
              className="bg-black/40 border-primary/20 focus:border-primary font-mono text-sm"
              {...register("address")}
            />
            {errors.address && (
              <p className="text-xs text-destructive flex items-center gap-1">
                <AlertCircle className="w-3 h-3" />
                {errors.address.message}
              </p>
            )}
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="priority" className="font-mono text-xs uppercase text-primary/80">Scan Priority</Label>
            <Select onValueChange={(val) => setValue("priority", val as "LOW" | "MEDIUM" | "HIGH")} defaultValue="LOW">
              <SelectTrigger className="bg-black/40 border-primary/20 font-mono">
                <SelectValue placeholder="Select priority" />
              </SelectTrigger>
              <SelectContent className="bg-card border-primary/20">
                <SelectItem value="LOW" className="font-mono focus:bg-primary/20">LOW</SelectItem>
                <SelectItem value="MEDIUM" className="font-mono focus:bg-primary/20 text-amber-500">MEDIUM</SelectItem>
                <SelectItem value="HIGH" className="font-mono focus:bg-primary/20 text-red-500">HIGH</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <DialogFooter className="pt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setOpen(false)}
              className="border-muted bg-transparent hover:bg-white/5 font-mono"
            >
              CANCEL
            </Button>
            <Button 
              type="submit" 
              disabled={createAddress.isPending}
              className="bg-primary text-primary-foreground font-bold font-mono tracking-wide"
            >
              {createAddress.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  INITIALIZING...
                </>
              ) : (
                "INITIATE SCAN"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
