import { IStorage } from "./storage";
import { watsonx } from "./watsonx";

export class ScannerService {
  private isRunning: boolean = false;
  private storage: IStorage;
  private intervalId: NodeJS.Timeout | null = null;

  constructor(storage: IStorage) {
    this.storage = storage;
  }

  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    console.log("Scanner service started");
    
    // Simulate the loop
    this.intervalId = setInterval(() => this.simulationStep(), 5000);
  }

  stop() {
    this.isRunning = false;
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    console.log("Scanner service stopped");
  }

  private async simulationStep() {
    if (!this.isRunning) return;

    try {
      const step = Math.random();
      
      // 1. Discover new address (30% chance)
      if (step < 0.3) {
        const fakeAddr = `1${Math.random().toString(36).substring(2, 10)}...`;
        
        // Use WatsonX to analyze priority
        const analysis = await watsonx.analyzeAddressPriority({
            address: fakeAddr,
            txCount: Math.floor(Math.random() * 100),
            balance: (Math.random() * 10).toFixed(8)
        });

        await this.storage.createAddress({
          address: fakeAddr,
          balance: (Math.random() * 10).toFixed(8),
          txCount: Math.floor(Math.random() * 100),
          priority: analysis.priority,
          riskScore: analysis.likelihood,
          status: "pending"
        });
        
        await this.storage.createLog({
          level: "INFO",
          component: "Collector",
          message: `Discovered new address ${fakeAddr}. AI Priority: ${analysis.priority}`,
        });
      }

      // 2. Analyze pending address (50% chance)
      if (step > 0.3 && step < 0.8) {
        const [target] = await this.storage.getAddresses(1, undefined, "pending");
        if (target) {
          await this.storage.updateAddressStatus(target.id, "analyzed", Math.floor(Math.random() * 100));
          await this.storage.createLog({
            level: "INFO",
            component: "Analyzer",
            message: `Analyzed ${target.address}. Risk Score updated.`,
            details: { address: target.address }
          });
        }
      }

      // 3. Find Vulnerability (10% chance)
      if (step > 0.9) {
        const [target] = await this.storage.getAddresses(1, undefined, "analyzed");
        if (target) {
           await this.storage.updateAddressStatus(target.id, "vulnerable");
           await this.storage.createVulnerability({
             addressId: target.id,
             type: "nonce_reuse",
             severity: "CRITICAL",
             data: { r_value: "0x123..." },
             recoveredKey: null
           });
           await this.storage.createLog({
             level: "ERROR",
             component: "Alert System",
             message: `CRITICAL VULNERABILITY FOUND: ${target.address}`,
             details: { type: "nonce_reuse" }
           });
        }
      }

    } catch (err) {
      console.error("Scanner simulation error", err);
    }
  }
}
