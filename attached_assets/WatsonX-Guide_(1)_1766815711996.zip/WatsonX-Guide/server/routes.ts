import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { ScannerService } from "./scanner";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // === API ROUTES ===

  app.get(api.addresses.list.path, async (req, res) => {
    // Basic query param handling
    const priority = req.query.priority as string | undefined;
    const status = req.query.status as string | undefined;
    const limit = req.query.limit ? Number(req.query.limit) : 50;
    
    const addresses = await storage.getAddresses(limit, priority, status);
    res.json(addresses);
  });

  app.get(api.addresses.get.path, async (req, res) => {
    const id = Number(req.params.id);
    const address = await storage.getAddress(id);
    if (!address) return res.status(404).json({ message: "Address not found" });
    
    // In a real app we'd fetch vulns for this specific address too
    // For now returning the address structure as requested
    res.json({ ...address, vulnerabilities: [] }); 
  });

  app.post(api.addresses.create.path, async (req, res) => {
    try {
      const input = api.addresses.create.input.parse(req.body);
      const address = await storage.createAddress(input);
      res.status(201).json(address);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: "Validation failed" });
      }
      throw err;
    }
  });

  app.get(api.vulnerabilities.list.path, async (req, res) => {
    const vulns = await storage.getVulnerabilities();
    res.json(vulns);
  });

  app.get(api.logs.list.path, async (req, res) => {
    const limit = req.query.limit ? Number(req.query.limit) : 50;
    const logs = await storage.getLogs(limit);
    res.json(logs);
  });

  app.get(api.stats.get.path, async (req, res) => {
    const stats = await storage.getStats();
    res.json(stats);
  });

  // === SCANNER CONTROL ===
  
  const scanner = new ScannerService(storage);

  app.post(api.scanner.action.path, async (req, res) => {
    const { action } = req.body;
    
    if (action === 'start') {
      scanner.start();
      await storage.createLog({ 
        level: 'INFO', 
        component: 'Orchestrator', 
        message: 'Manual override: Scanner started', 
        details: { user: 'admin' } 
      });
    } else if (action === 'stop' || action === 'pause') {
      scanner.stop();
      await storage.createLog({ 
        level: 'WARNING', 
        component: 'Orchestrator', 
        message: 'Manual override: Scanner stopped', 
        details: { user: 'admin' } 
      });
    }

    res.json({ status: 'success', message: `Scanner ${action}ed` });
  });

  // Seed data if empty
  await seedDatabase();

  return httpServer;
}

async function seedDatabase() {
  const existing = await storage.getAddresses(1);
  if (existing.length === 0) {
    console.log("Seeding database...");
    
    // Create some initial addresses
    const addr1 = await storage.createAddress({
      address: "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa",
      balance: "50.00000000",
      txCount: 150,
      priority: "HIGH",
      status: "pending"
    });

    const addr2 = await storage.createAddress({
      address: "3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy",
      balance: "1200.50000000",
      txCount: 4500,
      priority: "MEDIUM",
      status: "analyzed"
    });

    await storage.createLog({
      level: "INFO",
      component: "System",
      message: "System initialized. Waiting for instruction.",
      details: { version: "1.0.0" }
    });
  }
}
