import { db } from "./db";
import { scannedAddresses, systemLogs, type InsertLog } from "@shared/schema";
import { eq } from "drizzle-orm";

export class WatsonXService {
  private apiKey: string;
  private projectID: string;
  private baseUrl: string;
  private accessToken: string | null = null;
  private tokenExpiry: number = 0;

  constructor() {
    this.apiKey = process.env.IBM_WATSONX_API_KEY || "";
    this.projectID = process.env.WATSONX_PROJECT_ID || "";
    this.baseUrl = process.env.WATSONX_URL || "https://us-south.ml.cloud.ibm.com";
  }

  isConfigured(): boolean {
    return !!this.apiKey && !!this.projectID;
  }

  private async authenticate() {
    if (this.accessToken && Date.now() < this.tokenExpiry) {
      return this.accessToken;
    }

    try {
      const params = new URLSearchParams();
      params.append("grant_type", "urn:ibm:params:oauth:grant-type:apikey");
      params.append("apikey", this.apiKey);

      const response = await fetch("https://iam.cloud.ibm.com/identity/token", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Accept": "application/json"
        },
        body: params
      });

      if (!response.ok) {
        throw new Error(`Authentication failed: ${response.statusText}`);
      }

      const data = await response.json();
      this.accessToken = data.access_token;
      // Expires in is usually in seconds, subtract a buffer
      this.tokenExpiry = Date.now() + (data.expires_in * 1000) - 60000;
      
      return this.accessToken;
    } catch (error) {
      console.error("WatsonX Authentication Error:", error);
      throw error;
    }
  }

  async analyzeAddressPriority(addressData: any): Promise<{ priority: string, likelihood: number }> {
    if (!this.isConfigured()) {
      console.warn("WatsonX not configured, using fallback logic");
      // Fallback logic
      return {
        priority: Math.random() > 0.7 ? "HIGH" : "MEDIUM",
        likelihood: Math.floor(Math.random() * 100)
      };
    }

    try {
      const token = await this.authenticate();
      
      const prompt = `
      Analyze this Bitcoin address data and determine priority for ECDSA vulnerability scanning.
      
      Address: ${addressData.address}
      Transaction Count: ${addressData.txCount}
      Balance: ${addressData.balance} BTC
      
      Return ONLY a JSON object with this format: {"priority": "HIGH/MEDIUM/LOW", "likelihood": <number 0-100>}
      `;

      const body = {
        model_id: "ibm/granite-13b-instruct-v2",
        project_id: this.projectID,
        input: prompt,
        parameters: {
          decoding_method: "greedy",
          max_new_tokens: 100,
          temperature: 0.1,
          repetition_penalty: 1.0
        }
      };

      const response = await fetch(`${this.baseUrl}/ml/v1/text/generation?version=2023-05-29`, {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${token}`,
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        throw new Error(`Inference failed: ${response.statusText}`);
      }

      const data = await response.json();
      const generatedText = data.results[0].generated_text;
      
      // Attempt to parse JSON from response
      try {
        // Find JSON in the response if there's extra text
        const jsonMatch = generatedText.match(/\{.*\}/s);
        const jsonStr = jsonMatch ? jsonMatch[0] : generatedText;
        return JSON.parse(jsonStr);
      } catch (e) {
        console.warn("Failed to parse LLM response JSON:", generatedText);
        return { priority: "MEDIUM", likelihood: 50 };
      }

    } catch (error) {
      console.error("WatsonX Analysis Error:", error);
      return { priority: "MEDIUM", likelihood: 50 };
    }
  }
}

export const watsonx = new WatsonXService();
