import axios from 'axios';

const WATSONX_URL = process.env.WATSONX_URL || 'https://us-south.ml.cloud.ibm.com';
const WATSONX_API_KEY = process.env.IBM_WATSONX_API_KEY;
const WATSONX_PROJECT_ID = process.env.WATSONX_PROJECT_ID;

export interface WatsonxConfig {
  url: string;
  apiKey: string;
  projectId: string;
}

export class WatsonxClient {
  private url: string;
  private apiKey: string;
  private projectId: string;
  private accessToken: string | null = null;

  constructor(config: WatsonxConfig) {
    this.url = config.url;
    this.apiKey = config.apiKey;
    this.projectId = config.projectId;
  }

  async authenticate(): Promise<boolean> {
    try {
      const response = await axios.post(
        `${this.url}/v1/auth/token`,
        { api_key: this.apiKey },
        { headers: { 'Content-Type': 'application/json' } }
      );
      this.accessToken = response.data.token;
      return true;
    } catch (error) {
      console.error('Watsonx authentication failed:', error);
      return false;
    }
  }

  async testConnection(): Promise<{ connected: boolean; message: string }> {
    try {
      const authenticated = await this.authenticate();
      if (!authenticated) {
        return { connected: false, message: 'Failed to authenticate with watsonx' };
      }

      // Try a simple API call to verify connection
      const response = await axios.get(
        `${this.url}/v1/projects/${this.projectId}`,
        {
          headers: {
            Authorization: `Bearer ${this.accessToken}`,
            'Content-Type': 'application/json',
          },
        }
      );

      return {
        connected: true,
        message: `Connected to watsonx successfully. Project: ${response.data.metadata?.name || this.projectId}`,
      };
    } catch (error: any) {
      return {
        connected: false,
        message: `Watsonx connection error: ${error.message}`,
      };
    }
  }

  async analyzeAddress(addressData: any): Promise<any> {
    try {
      if (!this.accessToken) {
        await this.authenticate();
      }

      const prompt = `Analyze this blockchain address for ECDSA vulnerability scanning:
Address: ${addressData.address}
Transaction Count: ${addressData.txCount}
Balance: ${addressData.balance}
Risk Score: ${addressData.riskScore}
Priority: ${addressData.priority}
Status: ${addressData.status}

Provide priority assessment (HIGH/MEDIUM/LOW) and vulnerability likelihood (0-100).`;

      // Placeholder for actual watsonx API call
      // In production, this would use the proper foundation model endpoint
      return {
        priority: addressData.priority || 'MEDIUM',
        likelihood: Math.floor(Math.random() * 100),
        recommendation: 'Requires vulnerability analysis',
      };
    } catch (error: any) {
      console.error('Analysis error:', error);
      return {
        priority: 'MEDIUM',
        likelihood: 0,
        error: error.message,
      };
    }
  }
}

let watsonxClient: WatsonxClient | null = null;

export function initializeWatsonx(): WatsonxClient {
  if (!watsonxClient) {
    if (!WATSONX_API_KEY || !WATSONX_PROJECT_ID) {
      throw new Error(
        'Missing watsonx configuration: IBM_WATSONX_API_KEY and WATSONX_PROJECT_ID required'
      );
    }

    watsonxClient = new WatsonxClient({
      url: WATSONX_URL,
      apiKey: WATSONX_API_KEY,
      projectId: WATSONX_PROJECT_ID,
    });
  }

  return watsonxClient;
}

export function getWatsonxClient(): WatsonxClient {
  if (!watsonxClient) {
    return initializeWatsonx();
  }
  return watsonxClient;
}
