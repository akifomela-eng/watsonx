import { db } from "./db";
import {
  scannedAddresses,
  vulnerabilities,
  systemLogs,
  type ScannedAddress,
  type InsertAddress,
  type Vulnerability,
  type InsertVulnerability,
  type SystemLog,
  type InsertLog,
  type DashboardStats
} from "@shared/schema";
import { eq, desc, sql } from "drizzle-orm";

export interface IStorage {
  // Addresses
  getAddresses(limit?: number, priority?: string, status?: string): Promise<ScannedAddress[]>;
  getAddress(id: number): Promise<ScannedAddress | undefined>;
  createAddress(address: InsertAddress): Promise<ScannedAddress>;
  updateAddressStatus(id: number, status: string, riskScore?: number): Promise<ScannedAddress>;
  
  // Vulnerabilities
  getVulnerabilities(): Promise<(Vulnerability & { address: string })[]>;
  createVulnerability(vuln: InsertVulnerability): Promise<Vulnerability>;
  
  // Logs
  getLogs(limit?: number): Promise<SystemLog[]>;
  createLog(log: InsertLog): Promise<SystemLog>;
  
  // Stats
  getStats(): Promise<DashboardStats>;
}

export class DatabaseStorage implements IStorage {
  async getAddresses(limit: number = 50, priority?: string, status?: string): Promise<ScannedAddress[]> {
    let query = db.select().from(scannedAddresses);
    
    // Simple dynamic filtering (Drizzle query builder style would be better but keeping simple)
    // Note: This is a simplified implementation. Real app would use dynamic where construction.
    if (priority) {
      // @ts-ignore
      query.where(eq(scannedAddresses.priority, priority));
    }
    
    return await query.orderBy(desc(scannedAddresses.createdAt)).limit(limit);
  }

  async getAddress(id: number): Promise<ScannedAddress | undefined> {
    const [addr] = await db.select().from(scannedAddresses).where(eq(scannedAddresses.id, id));
    return addr;
  }

  async createAddress(address: InsertAddress): Promise<ScannedAddress> {
    const [newAddr] = await db.insert(scannedAddresses).values(address).returning();
    return newAddr;
  }

  async updateAddressStatus(id: number, status: string, riskScore?: number): Promise<ScannedAddress> {
    const updates: any = { status, lastScanned: new Date() };
    if (riskScore !== undefined) updates.riskScore = riskScore;
    
    const [updated] = await db.update(scannedAddresses)
      .set(updates)
      .where(eq(scannedAddresses.id, id))
      .returning();
    return updated;
  }

  async getVulnerabilities(): Promise<(Vulnerability & { address: string })[]> {
    const result = await db.select({
      id: vulnerabilities.id,
      addressId: vulnerabilities.addressId,
      type: vulnerabilities.type,
      severity: vulnerabilities.severity,
      data: vulnerabilities.data,
      recoveredKey: vulnerabilities.recoveredKey,
      detectedAt: vulnerabilities.detectedAt,
      address: scannedAddresses.address
    })
    .from(vulnerabilities)
    .innerJoin(scannedAddresses, eq(vulnerabilities.addressId, scannedAddresses.id))
    .orderBy(desc(vulnerabilities.detectedAt))
    .limit(50);
    
    return result;
  }

  async createVulnerability(vuln: InsertVulnerability): Promise<Vulnerability> {
    const [newVuln] = await db.insert(vulnerabilities).values(vuln).returning();
    return newVuln;
  }

  async getLogs(limit: number = 50): Promise<SystemLog[]> {
    return await db.select()
      .from(systemLogs)
      .orderBy(desc(systemLogs.timestamp))
      .limit(limit);
  }

  async createLog(log: InsertLog): Promise<SystemLog> {
    const [newLog] = await db.insert(systemLogs).values(log).returning();
    return newLog;
  }

  async getStats(): Promise<DashboardStats> {
    const totalScanned = await db.select({ count: sql<number>`count(*)` }).from(scannedAddresses);
    const vulnerableCount = await db.select({ count: sql<number>`count(*)` }).from(vulnerabilities);
    const highPriorityCount = await db.select({ count: sql<number>`count(*)` }).from(scannedAddresses).where(eq(scannedAddresses.priority, 'HIGH'));
    
    return {
      totalScanned: Number(totalScanned[0].count),
      vulnerableCount: Number(vulnerableCount[0].count),
      highPriorityCount: Number(highPriorityCount[0].count),
      activeThreads: 4 // Simulated constant
    };
  }
}

export const storage = new DatabaseStorage();
